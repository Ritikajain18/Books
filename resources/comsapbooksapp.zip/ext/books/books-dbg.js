sap.ui.define([
    "sap/m/MessageToast"
], function(MessageToast) {
    'use strict';

    return {
        // create button added from open guided development
        // onInit: function(oEvent) {
        //     MessageToast.show("Custom handler invoked.");
        // }
    };
});
